from dataclasses import dataclass, field
from typing import Any

RISK_TIERS = {"ALLOW", "CAUTION", "RESTRICTED", "PROHIBITED"}
REDTEAM_VERDICTS = {"ALLOW", "ALLOW_WITH_CONSTRAINTS", "RESTRICT", "PROHIBIT"}

@dataclass
class ArchiveRecord:
    descriptor_cell: str
    artifact_hash: str
    score_vector: dict[str, float]
    risk_tier: str
    redteam_verdict: str | None
    proof_bundle_hash: str
    lineage_pointer: str | None = None

def scalar_quality(s: dict[str, float]) -> float:
    weights = {
        "feasibility": 0.16,
        "causal_coherence": 0.16,
        "impact_potential": 0.15,
        "mechanism_novelty": 0.13,
        "robustness": 0.10,
        "testability": 0.10,
        "safety_margin": 0.08,
        "reinvestment_value": 0.07,
        "compute_or_energy_leverage": 0.05,
    }
    return sum(weights[k] * s.get(k, 0.0) for k in weights)

def promotion_allowed(record: ArchiveRecord) -> bool:
    s = record.score_vector
    if record.risk_tier == "PROHIBITED":
        return False
    if record.risk_tier == "RESTRICTED":
        return False
    if record.risk_tier == "CAUTION" and record.redteam_verdict not in {"ALLOW", "ALLOW_WITH_CONSTRAINTS"}:
        return False
    required = ["feasibility", "causal_coherence", "testability", "safety_margin"]
    if any(s.get(k, 0.0) < 4 for k in required):
        return False
    return any(s.get(k, 0.0) >= 4 for k in ["impact_potential", "mechanism_novelty", "reinvestment_value"])
