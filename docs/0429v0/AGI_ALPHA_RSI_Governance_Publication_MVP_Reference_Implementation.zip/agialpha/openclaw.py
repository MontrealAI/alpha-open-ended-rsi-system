def create_mandate(goal: str, budget: float, policy_hash: str) -> dict:
    return {"goal": goal, "budget": budget, "policy_hash": policy_hash, "state": "draft"}

def inspect_quarantine(quarantine_records: list[dict]) -> dict:
    return {"count": len(quarantine_records), "requires_reviewer": len(quarantine_records) > 0}

def approve_restricted_candidate(candidate_hash: str, reviewer_id: str, constraints: list[str]) -> dict:
    return {"candidate_hash": candidate_hash, "reviewer_id": reviewer_id, "constraints": constraints, "decision": "approved_with_constraints"}

def export_public_proof_pack(epoch_id: str, roots: dict) -> dict:
    return {"epoch_id": epoch_id, "roots": roots, "public_safe": True}
