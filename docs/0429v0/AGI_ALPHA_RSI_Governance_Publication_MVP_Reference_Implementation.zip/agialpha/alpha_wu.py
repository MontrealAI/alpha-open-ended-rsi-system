
def alpha_wu(hardware_normalized_metering: float, difficulty_tier: float, quality_score: float, slo_score: float, validator_confidence: float, policy_pass: bool, accepted: bool) -> float:
    if not accepted or not policy_pass or slo_score <= 0:
        return 0.0
    return float(hardware_normalized_metering * difficulty_tier * quality_score * slo_score * validator_confidence)

def d_real_agiet(success_rate: float, validated_alpha_wu: float, total_cost: float, critical_risk: float, coordination_overhead: float) -> float:
    denom = max(total_cost, 1e-9)
    return success_rate * (validated_alpha_wu / denom) * (1 - critical_risk) * (1 - coordination_overhead)
