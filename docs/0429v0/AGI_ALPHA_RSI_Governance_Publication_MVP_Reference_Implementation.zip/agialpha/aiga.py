from dataclasses import dataclass, field
from typing import Any, Literal

ObjectType = Literal["task","environment","agent_design","workflow","validator","tool_contract","market_mechanism","proof_template","curriculum","temporal_option","capability_package"]

@dataclass
class GeneratedObject:
    object_id: str
    object_type: ObjectType
    payload: dict[str, Any]
    generator_agent: str
    parent_archive_entries: list[str] = field(default_factory=list)
    novelty_score: float = 0.0
    interestingness_score: float = 0.0
    learnability_score: float = 0.0
    replayable: bool = False
    validator_bound: bool = False
    sandbox_safe: bool = False
    risk_bounded: bool = False
    produces_or_improves_verified_work: bool = False

def admit_generated_object(obj: GeneratedObject) -> bool:
    return all([
        obj.novelty_score > 0.0,
        obj.interestingness_score > 0.0,
        0.05 <= obj.learnability_score <= 0.95,
        obj.replayable,
        obj.validator_bound,
        obj.sandbox_safe,
        obj.risk_bounded,
        obj.produces_or_improves_verified_work,
    ])

def d_open(report: dict[str, float]) -> float:
    numerator_keys = [
        "verified_novelty", "learnability", "interestingness", "transferability",
        "reusability", "lineage_metaproductivity", "proof_replayability", "flywheel_contribution"
    ]
    denominator_keys = [
        "compute_cost", "coordination_cost", "safety_risk", "validator_risk",
        "reward_hacking_risk", "namespace_risk"
    ]
    numerator = 1.0
    for key in numerator_keys:
        numerator *= max(float(report.get(key, 0.0)), 0.0)
    denominator = sum(max(float(report.get(key, 0.0)), 0.0) for key in denominator_keys)
    return numerator / max(denominator, 1e-9)
