import hashlib, json

def hash_receipt(receipt: dict) -> str:
    return hashlib.sha256(json.dumps(receipt, sort_keys=True).encode()).hexdigest()

def merkleish_root(items: list[str]) -> str:
    # Minimal deterministic placeholder for MVP evidence; replace with a proper Merkle tree in production.
    return hashlib.sha256("|".join(sorted(items)).encode()).hexdigest()

def commit_epoch_roots(receipts: list[dict], payouts: list[dict], archive_deltas: list[dict], quarantines: list[dict]) -> dict:
    return {
        "receipt_root": merkleish_root([hash_receipt(x) for x in receipts]),
        "payout_root": merkleish_root([hash_receipt(x) for x in payouts]),
        "archive_delta_root": merkleish_root([hash_receipt(x) for x in archive_deltas]),
        "quarantine_root": merkleish_root([hash_receipt(x) for x in quarantines]),
    }
