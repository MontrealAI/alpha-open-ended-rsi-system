from dataclasses import dataclass, field
from typing import Any

MICROJOB_TYPES = [
    "PROPOSE", "CAUSALIZE", "SCORE_FAST", "SCORE_LCM", "NOVELTY",
    "REDTEAM", "ARCHIVE_INSERT", "VALIDATE_REPLAY", "PROMOTE_CANDIDATE",
    "PACKAGE_CAPABILITY", "UPDATE_INSIGHT_SIGNAL",
]

@dataclass
class Mandate:
    goal: str
    budget: float
    policy_hash: str
    descriptor_schema_hash: str
    scoring_rubric_hash: str
    safety_policy_hash: str
    validator_policy_hash: str
    promotion_thresholds: dict[str, Any] = field(default_factory=dict)
    reinvestment_policy: dict[str, Any] = field(default_factory=dict)

@dataclass
class MandateEpoch:
    mandate_id: str
    epoch_id: str
    receipt_root: str | None = None
    payout_root: str | None = None
    archive_delta_root: str | None = None
    quarantine_root: str | None = None
    validator_attestation_bundle: list[dict[str, Any]] = field(default_factory=list)
    challenge_window: str | None = None
    payout_budget: float = 0.0
    metadata_uri: str | None = None

def authorize_microjob(job_type: str, risk_tier: str) -> bool:
    if job_type not in MICROJOB_TYPES:
        return False
    if risk_tier == "PROHIBITED":
        return False
    return True
