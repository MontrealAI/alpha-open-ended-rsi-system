from __future__ import annotations
from dataclasses import dataclass
from typing import Literal

NodeRole = Literal['worker','validator','sentinel']

@dataclass
class AGIAlphaNode:
    ens_name: str
    role: NodeRole
    staked: bool
    authorized: bool
    container_digest: str
    telemetry_signing_key_id: str
    paused: bool = False

    def fail_closed(self, reason: str) -> dict:
        self.paused = True
        return {'node': self.ens_name, 'paused': True, 'reason': reason}

    def can_execute(self) -> bool:
        return self.staked and self.authorized and not self.paused and self.role in {'worker','validator','sentinel'}
