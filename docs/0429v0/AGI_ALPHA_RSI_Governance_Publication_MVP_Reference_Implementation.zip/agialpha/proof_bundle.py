
from dataclasses import dataclass, field
from typing import Any

@dataclass
class ProofBundle:
    job_spec: dict[str, Any]
    policy_context: dict[str, Any]
    env_pins: dict[str, Any]
    container_digest: str
    sbom: str
    dependency_pins: list[str]
    seeds: list[str]
    input_hashes: list[str]
    output_hashes: list[str]
    logs: list[dict[str, Any]] = field(default_factory=list)
    traces: list[dict[str, Any]] = field(default_factory=list)
    metering_telemetry: dict[str, Any] = field(default_factory=dict)
    worker_signature: str = ''
    node_signature: str = ''
    validator_commitments: list[str] = field(default_factory=list)
    validator_reveals: list[dict[str, Any]] = field(default_factory=list)
    dispute_record: dict[str, Any] = field(default_factory=dict)
    replay_result: dict[str, Any] = field(default_factory=dict)
    settlement_receipt: dict[str, Any] = field(default_factory=dict)
    chronicle_pointer: str = ''

def accept_job(bundle: ProofBundle, slo_pass: bool, policy_pass: bool, no_critical_violation: bool, dispute_window_closed: bool) -> bool:
    replay_ok = bool(bundle.replay_result.get('passed'))
    commit_reveal_clear = all(r.get('accepted') for r in bundle.validator_reveals) if bundle.validator_reveals else False
    return bool(replay_ok and commit_reveal_clear and slo_pass and policy_pass and no_critical_violation and dispute_window_closed)
