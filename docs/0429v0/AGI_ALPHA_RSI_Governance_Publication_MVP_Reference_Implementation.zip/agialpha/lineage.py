def lineage_metaproductivity(descendants, lambda_cost=0.1, rho_risk=1.0, kappa_hack=1.0):
    if not descendants: return 0.0
    scores=[]
    for d in descendants:
        scores.append(d.get("verified_value",0)-lambda_cost*d.get("cost",0)-rho_risk*d.get("risk",0)-kappa_hack*d.get("reward_hacking",0))
    return max(scores)
