from dataclasses import dataclass
from typing import Any

ACTIONS = ("delegate", "retrieve", "code", "test", "validate", "escalate", "stop", "quarantine", "settle")

@dataclass
class PlanningPrediction:
    action: str
    reward: float
    value: float
    safety_cost: float
    latency_cost: float
    validator_risk: float

@dataclass
class PlanningResult:
    selected_action: str
    pi_search: dict[str, float]
    nu_search: float
    predictions: list[PlanningPrediction]
    constraints: dict[str, Any]
    notes: str = "ProofZero MVP uses transparent heuristic predictions; production replaces this with learned evidence dynamics."

class ProofEquivalentOrganizationalModel:
    def encode(self, evidence_state: dict[str, Any]) -> dict[str, Any]:
        return {
            "task_family": evidence_state.get("task_family", "unknown"),
            "risk_class": evidence_state.get("risk_class", "low"),
            "tests_available": bool(evidence_state.get("tests_available", True)),
            "budget_remaining": float(evidence_state.get("budget_remaining", 1.0)),
            "validator_available": bool(evidence_state.get("validator_available", True)),
        }

    def predict(self, z: dict[str, Any], action: str) -> PlanningPrediction:
        risk = {"low": 0.02, "medium": 0.10, "high": 0.25}.get(z.get("risk_class", "low"), 0.10)
        if action == "validate":
            reward, value, safety = 0.35, 0.55, risk * 0.5
        elif action == "test":
            reward, value, safety = 0.25, 0.45, risk * 0.4
        elif action == "code":
            reward, value, safety = 0.20, 0.50, risk * 1.2
        elif action == "quarantine":
            reward, value, safety = -0.05, 0.10, 0.0
        elif action == "settle":
            reward, value, safety = 0.30, 0.40, risk
        else:
            reward, value, safety = 0.10, 0.30, risk
        latency = 0.03 if action in {"stop", "settle"} else 0.08
        validator_risk = 0.0 if z.get("validator_available", True) else 0.4
        return PlanningPrediction(action, reward, value, safety, latency, validator_risk)

def bounded_hypothetical_work_search(evidence_state: dict[str, Any], constraints: dict[str, Any]) -> PlanningResult:
    model = ProofEquivalentOrganizationalModel()
    z = model.encode(evidence_state)
    allowed = tuple(a for a in ACTIONS if a in set(constraints.get("allowed_actions", ACTIONS)))
    predictions = [model.predict(z, a) for a in allowed]
    def score(p: PlanningPrediction) -> float:
        return p.reward + p.value - p.safety_cost - p.latency_cost - p.validator_risk
    scored = sorted(((score(p), p) for p in predictions), key=lambda x: x[0], reverse=True)
    denom = sum(max(0.001, s) for s, _ in scored) or 1.0
    pi = {p.action: max(0.001, s) / denom for s, p in scored}
    best_score, best = scored[0]
    return PlanningResult(best.action, pi, best_score, predictions, constraints)

@dataclass
class SOTADiagnostics:
    delta_search: float
    depth_curve: dict[int, float]
    plateau_depth: int | None
    latent_state_score: float
    deployable: bool
    notes: str

def score_policy(pi: dict[str, float], action_values: dict[str, float]) -> float:
    return sum(pi.get(a, 0.0) * action_values.get(a, 0.0) for a in set(pi) | set(action_values))

def search_policy_improvement(base_pi: dict[str, float], result: PlanningResult) -> float:
    action_values = {
        p.action: p.reward + p.value - p.safety_cost - p.latency_cost - p.validator_risk
        for p in result.predictions
    }
    return score_policy(result.pi_search, action_values) - score_policy(base_pi, action_values)

def planning_depth_scaling(evidence_state: dict[str, Any], constraints: dict[str, Any], max_depth: int = 5) -> dict[int, float]:
    curve: dict[int, float] = {}
    allowed = list(constraints.get('allowed_actions', ACTIONS))
    for depth in range(1, max_depth + 1):
        subset = allowed[:max(1, min(len(allowed), depth + 1))]
        r = bounded_hypothetical_work_search(evidence_state, {**constraints, 'allowed_actions': subset})
        curve[depth] = r.nu_search
    return curve

def detect_plateau(curve: dict[int, float], eps: float = 0.01) -> int | None:
    prev = None
    for k in sorted(curve):
        if prev is not None and abs(curve[k] - prev) <= eps:
            return k
        prev = curve[k]
    return None

def latent_state_diagnostics(evidence_state: dict[str, Any]) -> dict[str, float]:
    model = ProofEquivalentOrganizationalModel()
    z = model.encode(evidence_state)
    decision_predictiveness = 1.0 if z.get('tests_available') else 0.5
    search_utility = 1.0 if z.get('validator_available') else 0.4
    compression_efficiency = 1.0 / max(1.0, len(str(z)) / 80.0)
    separability_calibration = 0.8 if z.get('task_family') != 'unknown' else 0.4
    safety_probeability = 1.0 if z.get('risk_class') in {'low','medium','high'} else 0.3
    return {
        'decision_predictiveness': decision_predictiveness,
        'search_utility': search_utility,
        'compression_efficiency': compression_efficiency,
        'separability_calibration': separability_calibration,
        'safety_probeability': safety_probeability,
    }

def sota_diagnostics(evidence_state: dict[str, Any], constraints: dict[str, Any], base_pi: dict[str, float] | None = None) -> SOTADiagnostics:
    base_pi = base_pi or {'code': 0.34, 'test': 0.33, 'validate': 0.33}
    result = bounded_hypothetical_work_search(evidence_state, constraints)
    delta = search_policy_improvement(base_pi, result)
    curve = planning_depth_scaling(evidence_state, constraints)
    plateau = detect_plateau(curve)
    diag = latent_state_diagnostics(evidence_state)
    latent_score = sum(diag.values()) / len(diag)
    deployable = delta > 0 and latent_score >= 0.7 and not evidence_state.get('critical_safety_violation', False)
    return SOTADiagnostics(
        delta_search=delta,
        depth_curve=curve,
        plateau_depth=plateau,
        latent_state_score=latent_score,
        deployable=deployable,
        notes='MVP diagnostics demonstrate the audit interface; production must validate on real tasks with evidence bundles.'
    )
