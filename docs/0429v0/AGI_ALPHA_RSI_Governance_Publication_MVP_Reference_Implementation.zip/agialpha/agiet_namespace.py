
from dataclasses import dataclass
from typing import Literal

Role = Literal['agent','node','club']

@dataclass(frozen=True)
class AGIEthName:
    entity: str
    role: Role
    env: str | None = None
    root: str = 'agi.eth'

    @property
    def name(self) -> str:
        if self.env:
            return f'{self.entity}.{self.env}.{self.role}.{self.root}'
        return f'{self.entity}.{self.role}.{self.root}'

def namespace_risk(ambiguity=0, collision=0, spoof=0, unauthorized_alias=0, resolver_instability=0, registry_drift=0, scope_confusion=0, weights=None):
    w = weights or [1,1,1,1,1,1,1]
    vals = [ambiguity, collision, spoof, unauthorized_alias, resolver_instability, registry_drift, scope_confusion]
    return sum(a*b for a,b in zip(w, vals))

def low_entropy_quality(r_namespace: float) -> float:
    return 1.0 / (1.0 + max(0.0, r_namespace))

def normalize_name(name: str) -> str:
    return name.strip().lower()
