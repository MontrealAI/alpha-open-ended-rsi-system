from __future__ import annotations
import hashlib, json
from dataclasses import dataclass
from typing import Any

def canonical_json_bytes(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')

def sha256_obj(obj: Any) -> str:
    return hashlib.sha256(canonical_json_bytes(obj)).hexdigest()

def state_payload_for_hash(state: dict) -> dict:
    s = json.loads(json.dumps(state))
    sm = s.setdefault('state_manifest', {})
    sm['state_payload_hash'] = None
    if isinstance(sm.get('drift_override'), dict):
        sm['drift_override']['ack_state_payload_hash'] = None
    return s

@dataclass
class DriftCheck:
    ok: bool
    prompt_pack_hash: str
    runner_config_hash: str
    state_payload_hash: str
    reason: str | None = None

def drift_check(prompt_pack: dict, runner_config: dict, state: dict) -> DriftCheck:
    ph = sha256_obj(prompt_pack)
    rh = sha256_obj(runner_config)
    sh = sha256_obj(state_payload_for_hash(state))
    sm = state.get('state_manifest', {})
    expected = {
        'prompt_pack_hash': sm.get('prompt_pack_hash'),
        'runner_config_hash': sm.get('runner_config_hash'),
        'state_payload_hash': sm.get('state_payload_hash'),
    }
    mismatches = []
    if expected['prompt_pack_hash'] and expected['prompt_pack_hash'] != ph:
        mismatches.append('prompt_pack_hash')
    if expected['runner_config_hash'] and expected['runner_config_hash'] != rh:
        mismatches.append('runner_config_hash')
    if expected['state_payload_hash'] and expected['state_payload_hash'] != sh:
        mismatches.append('state_payload_hash')
    if not mismatches:
        return DriftCheck(True, ph, rh, sh)
    override = sm.get('drift_override') or {}
    ok = (
        override.get('authorized') is True and
        override.get('ack_prompt_pack_hash') == ph and
        override.get('ack_runner_config_hash') == rh and
        override.get('ack_state_payload_hash') == sh
    )
    return DriftCheck(ok, ph, rh, sh, None if ok else 'DRIFT_SENTINEL_HARD_FAIL:' + ','.join(mismatches))
