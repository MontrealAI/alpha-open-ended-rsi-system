
# ProofZero planning layer available in agialpha.planning

# AGI.Eth institutional layer modules: agiet_namespace, proof_bundle, alpha_wu, agiet_node

# proof-gated AI-generating work engine helpers live in agialpha.aiga
