REQUIRED = {"evidence_bundle", "validator_score", "cost_ledger", "safety_ledger", "lineage_pointer", "replay_path"}

def admit_to_frontier(candidate):
    missing = [k for k in REQUIRED if not candidate.get(k)]
    return {"admitted": not missing, "missing": missing}
