def curriculum_from_task(task):
    return {
        "easier_variants": [], "harder_variants": [], "adversarial_variants": [],
        "decomposed_subtasks": [], "withheld_validators": []
    }

def allow_synthetic_update(record):
    return bool(record.get("held_out_validator_refs")) and record.get("false_acceptance", 0) == 0
