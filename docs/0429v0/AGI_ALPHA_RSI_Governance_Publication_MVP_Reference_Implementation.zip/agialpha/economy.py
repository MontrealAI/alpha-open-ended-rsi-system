from dataclasses import dataclass

@dataclass
class MarketState:
    market_type: str
    permeability: float
    stress_index: float = 0.0

def gate_permeability(state: MarketState, risk: float, validator_confidence: float) -> float:
    safe = max(0.0, min(1.0, validator_confidence * (1.0 - risk) * (1.0 - state.stress_index)))
    return min(state.permeability, safe)
