def insight_score(signal: dict) -> float:
    numerator = (
        signal.get("frequency", 0.0)
        * signal.get("reusability", 0.0)
        * signal.get("cost_decline", 0.0)
        * signal.get("transferability", 0.0)
        * signal.get("capitalizability", 0.0)
        * signal.get("infrastructure_compute_energy_relevance", 0.0)
    )
    denominator = (
        signal.get("risk", 0.0)
        + signal.get("regulatory_friction", 0.0)
        + signal.get("validator_burden", 0.0)
        + signal.get("uncertainty", 0.0)
        + 1e-9
    )
    return numerator / denominator
