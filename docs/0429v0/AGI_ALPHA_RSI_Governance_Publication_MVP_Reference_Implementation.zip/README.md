# AGI ALPHA MVP Reference Implementation

This scaffold implements the minimal validator-gated loop described in the paper:

1. load a real task manifest;
2. route a small agent constellation through the router-family interface (R0 Hamiltonian baseline in this MVP);
3. execute through bounded tools;
4. validate externally through tests and policy checks;
5. emit an evidence bundle;
6. update reputation and compare against baseline modes.

Run the deterministic software-repair demonstration:

```bash
cd mvp_reference
python main.py
```

The demo creates a local software-repair task, applies a patch through the bounded tool interface, runs tests, validates the result, and writes a machine-readable evidence bundle under `runs/evidence/`.

This is not a claim of AGI. It is a minimal, reproducible control-plane implementation for demonstrating the paper's coordination standard. The commercial architecture is the R0-R5 router family; this reference scaffold starts with R0 so every decision is transparent and auditable.


## Experience-grounded extension

The MVP now includes `agialpha/experience.py`, which defines:

- `ExperienceEvent`: the AGI ALPHA event tuple `(s_t, a_t, o_{t+1}, r_t, v_t, c_t, rho_t, m_t)`.
- `SovereignExperienceStream`: append-only trace storage, replay hashes, learning eligibility gates, and compressed router priors.

This is intentionally minimal and commercially independent. It does not implement any third-party algorithm. It demonstrates how evidence bundles become experience streams for router updates, reward governance, and replayable safety review.

## ProofZero planning layer

The MVP includes `agialpha/planning.py`, a transparent placeholder for AGI ALPHA-native planning with learned organizational models. It exposes:

- `ProofEquivalentOrganizationalModel`
- `bounded_hypothetical_work_search`
- organizational actions: delegate, retrieve, code, test, validate, escalate, stop, quarantine, settle

The MVP implementation is intentionally heuristic and auditable. Production use requires learned Latent Evidence Dynamics, validator-aware tree planning, Evidence Reanalyze, and Cost-Risk-Value Backup trained from evidence streams. It does not depend on MuZero code, pseudocode, architecture, hyperparameters, training recipes, weights, data, or implementation details.


## AGI.Eth institutional layer

This MVP scaffold now includes AGI.Eth-native utilities:

- `agiet_namespace.py`: namespace parsing, registry recognition, namespace risk, low-entropy quality.
- `proof_bundle.py`: settlement-grade ProofBundle object and acceptance rule.
- `alpha_wu.py`: α-Work Unit metrology and `D_real^AGI.Eth`.
- `agiet_node.py`: ENS-identified worker/validator/sentinel runtime model.

These are independent reference interfaces for the AGI ALPHA paper. They do not imply achieved AGI/ASI, token investment claims, or production readiness.


## Proof-Gated AI-Generating Work Engine

The MVP scaffold now includes `agialpha/aiga.py`, which defines generated-object records, an admissibility gate, and a simple `D_open` calculation. Generated tasks, environments, agent designs, validators, and proof templates should remain unofficial until proof-bundle replay, safety review, held-out validation, and AGI.Eth registry recognition pass.


## Market-governed invention MVP additions

This package now includes minimal scaffolds for MandateEpoch batching, QD archive promotion, OpenClaw operator actions, NettingHouse roots, and alpha-AGI Insight stepping-stone scoring. These are reference scaffolds, not production protocol code.
