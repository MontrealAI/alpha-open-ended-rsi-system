def coordination_overhead(bundle):
    handoffs = sum(1 for e in bundle.trace if e.kind in {"handoff", "message"})
    duplicate = sum(1 for e in bundle.trace if e.kind == "duplicate_work")
    validator = sum(1 for e in bundle.trace if e.kind == "validation")
    total = max(1, len(bundle.trace))
    return min(1.0, (handoffs + duplicate + validator) / total)

def d_real(bundles):
    accepted = sum(b.validation.accepted for b in bundles) / max(1, len(bundles))
    verified_work = sum(b.validation.score for b in bundles)
    total_cost = sum(max(0.01, b.cost.dollars + b.cost.wall_seconds / 3600) for b in bundles)
    critical_risk = 1.0 if any(b.validation.critical_violation for b in bundles) else 0.0
    overhead = sum(coordination_overhead(b) for b in bundles) / max(1, len(bundles))
    return accepted * (verified_work / total_cost) * (1 - critical_risk) * (1 - overhead)
