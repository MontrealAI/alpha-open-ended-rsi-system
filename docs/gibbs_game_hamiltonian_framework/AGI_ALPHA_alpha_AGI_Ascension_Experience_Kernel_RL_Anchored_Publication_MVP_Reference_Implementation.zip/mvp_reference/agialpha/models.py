from __future__ import annotations
from pydantic import BaseModel, Field
from typing import Literal, Any

Risk = Literal["low", "medium", "high"]
Role = Literal["planner", "coder", "tester", "reviewer", "validator", "retriever"]

class Job(BaseModel):
    id: str
    family: str
    objective: str
    repo_path: str | None = None
    constraints: list[str] = []
    success_cmd: str
    risk: Risk = "low"
    budget_tokens: int = 100_000
    allowed_tools: set[str] = {"read_file", "search_repo", "write_patch", "run_tests"}

class AgentProfile(BaseModel):
    id: str
    role: Role
    capabilities: set[str]
    allowed_tools: set[str]
    reputation: float = 0.5
    avg_cost: float = 1.0
    risk_score: float = 0.05
    success_by_family: dict[str, float] = Field(default_factory=dict)

class TraceEvent(BaseModel):
    ts: float
    agent_id: str
    kind: str
    payload: dict[str, Any]

class ValidationRecord(BaseModel):
    accepted: bool
    score: float
    tests_passed: bool
    policy_ok: bool
    critical_violation: bool = False
    report: str = ""

class CostLedger(BaseModel):
    tokens: int = 0
    tool_calls: int = 0
    wall_seconds: float = 0
    human_minutes: float = 0
    dollars: float = 0

class EvidenceBundle(BaseModel):
    job: Job
    selected_agents: list[str]
    rejected_agents: list[str]
    trace: list[TraceEvent]
    artifact: dict[str, Any]
    validation: ValidationRecord
    cost: CostLedger
    safety_ledger: list[dict[str, Any]] = []
    settlement: dict[str, Any] = {}
