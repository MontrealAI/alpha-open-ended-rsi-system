import time
from agialpha.models import EvidenceBundle, TraceEvent, CostLedger
from agialpha.router import select_constellation
from agialpha.validators import validate
from agialpha.settlement import settle

def call_agent(agent, job, context, llm):
    prompt = f"""Role: {agent.role}\nObjective: {job.objective}\nConstraints: {job.constraints}\nContext: {context}\nReturn only actionable output."""
    return llm(agent.role, prompt)

def run_agialpha(job, agents, tools, llm):
    t0 = time.time()
    selected, rejected, h_score = select_constellation(job, agents)
    trace, cost = [], CostLedger()

    def log(agent, kind, payload):
        trace.append(TraceEvent(ts=time.time(), agent_id=agent.id, kind=kind, payload=payload))

    planner = next((a for a in selected if a.role == "planner"), selected[0])
    plan = call_agent(planner, job, "Create a minimal repair plan.", llm)
    log(planner, "plan", {"text": plan, "hamiltonian_score": h_score})

    coder = next(a for a in selected if a.role == "coder")
    diff = call_agent(coder, job, f"Plan:\n{plan}\nProduce a unified git diff.", llm)
    log(coder, "patch_proposed", {"diff": diff})

    patch_result = tools.write_patch(diff)
    cost.tool_calls += 1
    log(coder, "patch_apply", patch_result)

    test_result = tools.run_tests(job.success_cmd)
    cost.tool_calls += 1
    tester = next((a for a in selected if a.role == "tester"), coder)
    log(tester, "tests", test_result)

    validation = validate(job, test_result, trace)
    validator = next(a for a in selected if a.role == "validator")
    log(validator, "validation", validation.model_dump())

    cost.wall_seconds = time.time() - t0
    settlement = settle(selected, validation, cost)
    artifact = {"patch": diff, "test_result": test_result}

    return EvidenceBundle(
        job=job,
        selected_agents=[a.id for a in selected],
        rejected_agents=list(dict.fromkeys(rejected)),
        trace=trace,
        artifact=artifact,
        validation=validation,
        cost=cost,
        safety_ledger=[{"critical_violation": validation.critical_violation, "policy_ok": validation.policy_ok}],
        settlement=settlement,
    )
