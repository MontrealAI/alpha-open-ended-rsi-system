def settle(team, validation, cost):
    delta = 0.05 if validation.accepted else -0.03
    out = {}
    for a in team:
        role_bonus = 0.02 if validation.accepted and a.role in {"coder", "validator"} else 0.0
        out[a.id] = {
            "old_reputation": a.reputation,
            "new_reputation": max(0.0, min(1.0, a.reputation + delta + role_bonus)),
            "reward": validation.score * (1.0 + role_bonus),
        }
    return out
