from __future__ import annotations
from pathlib import Path
import subprocess, time

class ToolBox:
    def __init__(self, root: str):
        self.root = Path(root).resolve()

    def _safe(self, path: str) -> Path:
        p = (self.root / path).resolve()
        if not str(p).startswith(str(self.root)):
            raise ValueError("path escape")
        return p

    def read_file(self, path: str) -> str:
        return self._safe(path).read_text(errors="ignore")

    def search_repo(self, term: str) -> list[str]:
        hits = []
        for p in self.root.rglob("*.py"):
            text = p.read_text(errors="ignore")
            if term in text:
                hits.append(str(p.relative_to(self.root)))
        return hits

    def write_patch(self, diff: str) -> dict:
        p = subprocess.run(["git", "apply", "-"], input=diff, text=True, cwd=self.root, capture_output=True)
        return {"ok": p.returncode == 0, "stdout": p.stdout, "stderr": p.stderr}

    def run_tests(self, cmd: str, timeout: int = 120) -> dict:
        t = time.time()
        p = subprocess.run(cmd, shell=True, cwd=self.root, capture_output=True, text=True, timeout=timeout)
        return {"ok": p.returncode == 0, "stdout": p.stdout[-4000:], "stderr": p.stderr[-4000:], "seconds": time.time() - t}
