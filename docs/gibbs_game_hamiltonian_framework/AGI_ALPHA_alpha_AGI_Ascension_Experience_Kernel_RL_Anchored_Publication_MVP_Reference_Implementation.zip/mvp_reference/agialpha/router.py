from itertools import combinations
from agialpha.models import AgentProfile, Job


# Router family contract. The MVP implements R0 for interpretability;
# production AGI ALPHA can promote R1-R5 only when evidence bundles show
# superior verified work under equal model/tool/budget constraints.
# R0: heuristic Hamiltonian baseline
# R1: natural-language workflow router
# R2: evidence-state lightweight router
# R3: evolutionary coordinator
# R4: reinforcement-learned coordinator
# R5: hybrid proof-conditioned router

ROLE_SYNERGY = {
    ("planner", "coder"): 0.30,
    ("coder", "tester"): 0.35,
    ("tester", "reviewer"): 0.25,
    ("reviewer", "validator"): 0.20,
    ("retriever", "planner"): 0.20,
}

def expected_value(a: AgentProfile, job: Job) -> float:
    return 0.7 * a.reputation + 0.3 * a.success_by_family.get(job.family, 0.5)

def pair_synergy(a: AgentProfile, b: AgentProfile) -> float:
    return ROLE_SYNERGY.get((a.role, b.role), ROLE_SYNERGY.get((b.role, a.role), 0.0))

def hamiltonian(team: tuple[AgentProfile, ...], job: Job) -> float:
    """R0 baseline score: cost + risk + overhead - value - synergy."""
    local_cost = sum(a.avg_cost for a in team)
    local_risk = sum(a.risk_score for a in team)
    value = sum(expected_value(a, job) for a in team)
    synergy = sum(pair_synergy(a, b) for i, a in enumerate(team) for b in team[i + 1:])
    overhead = 0.08 * (len(team) ** 2)
    forbidden = any(not a.allowed_tools <= job.allowed_tools for a in team)
    return 999.0 if forbidden else local_cost + 2 * local_risk + overhead - value - synergy

def select_constellation(job: Job, agents: list[AgentProfile], max_k: int = 4):
    """Select a team with R0; returned trace is compatible with R1-R5 routers."""
    candidates: list[tuple[float, tuple[AgentProfile, ...]]] = []
    for k in range(1, max_k + 1):
        for team in combinations(agents, k):
            roles = {a.role for a in team}
            if "validator" not in roles:
                continue
            if job.family == "software" and not {"planner", "coder", "tester"}.issubset(roles):
                continue
            candidates.append((hamiltonian(team, job), team))
    if not candidates:
        raise ValueError("No valid constellation found")
    candidates.sort(key=lambda x: x[0])
    selected = candidates[0][1]
    rejected = [a.id for _, team in candidates[1:4] for a in team]
    return list(selected), rejected, candidates[0][0]
