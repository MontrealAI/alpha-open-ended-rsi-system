from agialpha.models import ValidationRecord

BLOCKED_PATTERNS = ["rm -rf", "curl ", "wget ", "nc ", "ssh ", "sudo "]

def validate(job, test_result, trace):
    policy_ok = True
    critical = False
    joined = "\n".join(str(e.payload) for e in trace)
    for pattern in BLOCKED_PATTERNS:
        if pattern in joined:
            policy_ok = False
            critical = True
    tests_passed = bool(test_result.get("ok"))
    return ValidationRecord(
        accepted=tests_passed and policy_ok and not critical,
        score=1.0 if tests_passed and policy_ok and not critical else 0.0,
        tests_passed=tests_passed,
        policy_ok=policy_ok,
        critical_violation=critical,
        report=(test_result.get("stdout", "") + "\n" + test_result.get("stderr", "")).strip(),
    )
