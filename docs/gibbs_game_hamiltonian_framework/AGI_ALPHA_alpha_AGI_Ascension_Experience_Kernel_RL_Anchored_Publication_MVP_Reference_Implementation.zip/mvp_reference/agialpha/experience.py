from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any
import time, json, hashlib

@dataclass
class ExperienceEvent:
    s_t: dict[str, Any]
    a_t: dict[str, Any]
    o_t1: dict[str, Any]
    r_t: dict[str, Any]
    v_t: dict[str, Any]
    c_t: dict[str, Any]
    rho_t: dict[str, Any]
    m_t: dict[str, Any]
    ts: float = field(default_factory=time.time)
    provenance: list[str] = field(default_factory=list)

    def replay_hash(self) -> str:
        payload = json.dumps(asdict(self), sort_keys=True, default=str)
        return hashlib.sha256(payload.encode()).hexdigest()

class SovereignExperienceStream:
    def __init__(self):
        self.events: list[ExperienceEvent] = []

    def append(self, event: ExperienceEvent) -> dict[str, Any]:
        rec = asdict(event)
        rec["replay_hash"] = event.replay_hash()
        self.events.append(event)
        return rec

    def allowed_for_learning(self, event: ExperienceEvent) -> bool:
        v_ok = bool(event.v_t.get("accepted") or event.v_t.get("decision") == "accepted")
        risk_ok = not bool(event.rho_t.get("critical_violation"))
        reward_ok = not bool(event.r_t.get("reward_hacking_suspected"))
        return v_ok and risk_ok and reward_ok

    def compress_for_router(self) -> dict[str, Any]:
        safe = [e for e in self.events if self.allowed_for_learning(e)]
        return {
            "n_events": len(self.events),
            "n_safe_for_learning": len(safe),
            "accepted_rate": sum(1 for e in self.events if e.v_t.get("accepted")) / max(1, len(self.events)),
            "avg_reward": sum(float(e.r_t.get("reward", 0.0)) for e in safe) / max(1, len(safe)),
            "replay_hashes": [e.replay_hash() for e in safe[-25:]],
        }
