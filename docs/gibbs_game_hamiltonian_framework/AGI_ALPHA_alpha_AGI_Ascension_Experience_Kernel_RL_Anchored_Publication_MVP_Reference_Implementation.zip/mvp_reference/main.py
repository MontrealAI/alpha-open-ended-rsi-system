from __future__ import annotations
import json, shutil
from pathlib import Path
from agialpha.models import Job, AgentProfile
from agialpha.tools import ToolBox
from agialpha.orchestrator import run_agialpha
from agialpha.evals import d_real

PATCH = '''diff --git a/calculator.py b/calculator.py
index 2b8df17..c59a18e 100644
--- a/calculator.py
+++ b/calculator.py
@@ -3,4 +3,4 @@ def add(a, b):
 def divide(a, b):
     if b == 0:
         raise ZeroDivisionError("division by zero")
-    return a * b  # BUG: should divide
+    return a / b
'''

def scripted_llm(role: str, prompt: str) -> str:
    if role == "planner":
        return "Inspect calculator.divide, produce the smallest patch, then run pytest."
    if role == "coder":
        return PATCH
    return "Validate by running the specified test command and checking policy constraints."

def load_job(root: Path) -> Job:
    item = json.loads((root / "benchmarks/swe_lite/tasks.jsonl").read_text().splitlines()[0])
    item["repo_path"] = str(root / item["repo_path"])
    item["allowed_tools"] = set(item["allowed_tools"])
    return Job(**item)

def reset_demo_repo(root: Path):
    repo = root / "benchmarks/repos/toy_math"
    (repo / "calculator.py").write_text('''def add(a, b):\n    return a + b\n\ndef divide(a, b):\n    if b == 0:\n        raise ZeroDivisionError("division by zero")\n    return a * b  # BUG: should divide\n''')

def main():
    root = Path(__file__).resolve().parent
    reset_demo_repo(root)
    job = load_job(root)
    agents = [
        AgentProfile(id="planner.v0", role="planner", capabilities={"decompose", "plan"}, allowed_tools={"read_file", "search_repo"}, reputation=0.62),
        AgentProfile(id="coder.v0", role="coder", capabilities={"patch", "python"}, allowed_tools={"read_file", "search_repo", "write_patch", "run_tests"}, reputation=0.72),
        AgentProfile(id="tester.v0", role="tester", capabilities={"pytest", "regression"}, allowed_tools={"run_tests", "read_file"}, reputation=0.67),
        AgentProfile(id="validator.v0", role="validator", capabilities={"policy", "acceptance"}, allowed_tools={"run_tests", "read_file"}, reputation=0.80),
        AgentProfile(id="reviewer.v0", role="reviewer", capabilities={"review"}, allowed_tools={"read_file"}, reputation=0.55),
    ]
    bundle = run_agialpha(job, agents, ToolBox(job.repo_path), scripted_llm)
    out_dir = root / "runs/evidence"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"{job.id}.evidence.json"
    out_path.write_text(bundle.model_dump_json(indent=2))
    print(json.dumps({
        "evidence_bundle": str(out_path.relative_to(root)),
        "accepted": bundle.validation.accepted,
        "score": bundle.validation.score,
        "D_real_single_run": d_real([bundle]),
        "selected_agents": bundle.selected_agents,
    }, indent=2))

if __name__ == "__main__":
    main()
