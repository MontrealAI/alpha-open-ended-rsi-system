# AGI ALPHA MVP Reference Implementation

This scaffold implements the minimal validator-gated loop described in the paper:

1. load a real task manifest;
2. route a small agent constellation through the router-family interface (R0 Hamiltonian baseline in this MVP);
3. execute through bounded tools;
4. validate externally through tests and policy checks;
5. emit an evidence bundle;
6. update reputation and compare against baseline modes.

Run the deterministic software-repair demonstration:

```bash
cd mvp_reference
python main.py
```

The demo creates a local software-repair task, applies a patch through the bounded tool interface, runs tests, validates the result, and writes a machine-readable evidence bundle under `runs/evidence/`.

This is not a claim of AGI. It is a minimal, reproducible control-plane implementation for demonstrating the paper's coordination standard. The commercial architecture is the R0-R5 router family; this reference scaffold starts with R0 so every decision is transparent and auditable.


## Experience-grounded extension

The MVP now includes `agialpha/experience.py`, which defines:

- `ExperienceEvent`: the AGI ALPHA event tuple `(s_t, a_t, o_{t+1}, r_t, v_t, c_t, rho_t, m_t)`.
- `SovereignExperienceStream`: append-only trace storage, replay hashes, learning eligibility gates, and compressed router priors.

This is intentionally minimal and commercially independent. It does not implement any third-party algorithm. It demonstrates how evidence bundles become experience streams for router updates, reward governance, and replayable safety review.
